import urllib.parse

import xbmcplugin


class Router:
    """Explicit route dispatcher for Kodi plugin modes."""

    def __init__(self, context, handlers):
        self.context = context
        self.handlers = handlers

    @staticmethod
    def _sync_options(params):
        return {'background': True} if params.get('background') == '1' else {}

    def dispatch(self, paramstring=None):
        params = dict(urllib.parse.parse_qsl(
            self.context.paramstring if paramstring is None else paramstring
        ))
        mode = params.get('mode')
        if mode and mode not in ('profiles',):
            xbmcplugin.setContent(self.context.handle, 'videos')
        if not mode:
            self.handlers['main_menu']()
        elif mode == 'login':
            self.handlers['do_login']()
        elif mode == 'search':
            if params.get('q'):
                self.handlers['do_search'](params.get('q'))
            else:
                self.handlers['do_search']()
        elif mode == 'widgets':
            self.handlers['widgets_menu']()
        elif mode == 'widget':
            self.handlers['widget_list'](params.get('list'))
        elif mode == 'backup_lists':
            self.handlers['backup_lists']()
        elif mode == 'restore_lists':
            self.handlers['restore_lists']()
        elif mode == 'daily_check':
            self.handlers['daily_check']()
        elif mode == 'remote_watched':
            self.handlers['remote_watched'](params.get('id'), params.get('watched', '1'),
                                            params.get('background') == '1')
        elif mode == 'play_next':
            self.handlers['play_next'](params.get('id'), params.get('background') == '1')
        elif mode == 'toggle_stop_after':
            self.handlers['toggle_stop_after']()
        elif mode == 'shuffle':
            self.handlers['shuffle_series'](params.get('series_id'))
        elif mode == 'history':
            self.handlers['browse_history']()
        elif mode == 'clear_history':
            self.handlers['clear_history']()
        elif mode == 'record_history':
            self.handlers['record_history'](params.get('id'), params.get('title', ''),
                                            params.get('subtitle', ''), params.get('thumb', ''),
                                            params.get('media_type', ''), params.get('background') == '1')
        elif mode == 'mark_series_watched':
            self.handlers['mark_series_watched_route'](params.get('series_id'))
        elif mode == 'notify_new':
            self.handlers['notify_new'](params.get('background') == '1')
        elif mode == 'sync_resume':
            self.handlers['sync_resume'](params.get('background') == '1')
        elif mode == 'expiring':
            self.handlers['browse_expiring']()
        elif mode == 'both_continue':
            self.handlers['both_continue']()
        elif mode == 'favourite_channels':
            self.handlers['favourite_channels']()
        elif mode == 'check_reminders':
            self.handlers['check_reminders'](params.get('background') == '1')
        elif mode == 'import_trakt':
            self.handlers['import_trakt_watchlist'](params.get('background') == '1')
        elif mode == 'profiles':
            self.handlers['manage_profiles']()
        elif mode == 'watch_later':
            self.handlers['browse_watch_later']()
        elif mode == 'watch_later_collection':
            self.handlers['browse_watch_later_collection'](
                params.get('collection_id'),
                params.get('season')
            )
        elif mode == 'add_series_watch_later':
            self.handlers['add_series_watch_later'](
                params.get('series_id'),
                params.get('title'),
                params.get('from_now')
            )
        elif mode == 'my_series':
            self.handlers['browse_my_series']()
        elif mode == 'sync_watch_later':
            self.handlers['sync_watch_later'](**self._sync_options(params))
        elif mode == 'sync_my_series':
            self.handlers['sync_my_series'](**self._sync_options(params))
        elif mode == 'toggle_watch_later':
            self.handlers['toggle_watch_later'](
                params.get('id'),
                params.get('title'),
                params.get('type'),
                params.get('thumb'),
                params.get('group')
            )
        elif mode == 'toggle_my_series':
            self.handlers['toggle_my_series'](
                params.get('id'),
                params.get('title'),
                params.get('type'),
                params.get('thumb'),
                params.get('group')
            )
        elif mode == 'select_profile':
            self.handlers['select_profile'](params.get('profile_id'))
        elif mode == 'apply_profile':
            self.handlers['apply_profile']()
        elif mode == 'series':
            self.handlers['browse_series']()
        elif mode == 'logout':
            self.handlers['do_logout']()
        elif mode == 'logout_confirm':
            self.handlers['confirm_logout']()
        elif mode == 'account_summary':
            self.handlers['refresh_account_info']()
        elif mode == 'parental_set_pin':
            self.handlers['parental_set_pin']()
        elif mode == 'parental_clear_pin':
            self.handlers['parental_clear_pin']()
        elif mode == 'toggle_profile_lock':
            self.handlers['toggle_profile_lock'](params.get('profile_id'))
        elif mode == 'choose_tmdb':
            self.handlers['choose_tmdb'](params.get('kind'), params.get('id'))
        elif mode == 'library_from_lists':
            self.handlers['library_from_lists'](**self._sync_options(params))
        elif mode == 'diagnostics':
            self.handlers['run_diagnostics']()
        elif mode == 'export_diagnostics':
            self.handlers['export_diagnostics']()
        elif mode == 'clear_subtitle_cache':
            self.handlers['clear_subtitle_cache']()
        elif mode == 'clear_all_cache':
            self.handlers['clear_all_cache']()
        elif mode == 'browse_epg':
            self.handlers['browse_epg']()
        elif mode == 'search_group':
            if params.get('period') or params.get('genre'):
                self.handlers['search_group'](params.get('q'), params.get('group'),
                                              params.get('period'), params.get('genre'))
            else:
                self.handlers['search_group'](params.get('q'), params.get('group'))
        elif mode == 'search_filter':
            self.handlers['search_filter'](params.get('q'), params.get('group') or 'all',
                                           params.get('period'), params.get('genre'))
        elif mode == 'series_detail':
            self.handlers['show_series_detail'](params.get('series_id'))
        elif mode == 'series_season':
            self.handlers['show_series_season'](
                params.get('series_id'),
                params.get('season_id'),
                params.get('episodes_url'),
                params.get('series_title'),
                params.get('season_number')
            )
        elif mode == 'export_series_library':
            self.handlers['export_series_library'](params.get('series_id'))
        elif mode == 'library_toggle':
            self.handlers['library_toggle'](params.get('kind'), params.get('id'), params.get('title'),
                                            params.get('poster'), params.get('fanart'))
        elif mode == 'library_remove':
            self.handlers['library_remove'](params.get('kind'), params.get('id'), params.get('title'))
        elif mode == 'library_update':
            self.handlers['library_update'](**self._sync_options(params))
        elif mode == 'browse_library':
            self.handlers['browse_library']()
        elif mode == 'repair_library_art':
            self.handlers['repair_library_art'](background=params.get('background') == '1')
        elif mode == 'register_library_sources':
            self.handlers['register_library_sources']()
        elif mode == 'fix_library_sources':
            self.handlers['fix_library_sources']()
        elif mode == 'check_tmdb_key':
            self.handlers['check_tmdb_key']()
        elif mode == 'placement_row':
            self.handlers['browse_placement_row'](
                params.get('items_url'),
                params.get('placement_id'),
                params.get('comp_index')
            )
        elif mode == 'browse_tv_shows':
            self.handlers['browse_tv_shows']()
        elif mode == 'browse_tv_genre':
            self.handlers['browse_tv_genre'](params.get('genre'))
        elif mode == 'browse_series_categories':
            self.handlers['browse_series_categories']()
        elif mode == 'browse_series_genre':
            self.handlers['browse_series_genre'](params.get('genre'))
        elif mode == 'browse_movie_categories':
            self.handlers['browse_movie_categories']()
        elif mode == 'browse_movie_genre':
            self.handlers['browse_movie_genre'](params.get('genre'))
        elif mode == 'browse':
            self.handlers['browse_category'](params.get('type', 'all'))
        elif mode == 'play':
            content_id = params.get('id')
            params.pop('mode', None)
            params.pop('id', None)
            if content_id is None:
                pass
            else:
                self.handlers['play_item'](content_id, **params)
        elif mode == 'iptv-select-channels':
            self.handlers['select_iptv_channels']()
        elif mode == 'iptv-channels':
            from resources.lib import iptvmgr
            try:
                port = int(params.get('port'))
            except (TypeError, ValueError):
                port = 0
            iptvmgr.IPTVManager(port).send_channels()
        elif mode == 'iptv.epg':
            from resources.lib import iptvmgr
            try:
                port = int(params.get('port'))
            except (TypeError, ValueError):
                port = 0
            iptvmgr.IPTVManager(port).send_epg()
